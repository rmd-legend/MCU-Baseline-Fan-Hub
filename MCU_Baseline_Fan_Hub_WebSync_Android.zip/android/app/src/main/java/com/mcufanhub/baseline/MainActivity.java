package com.mcufanhub.baseline;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.view.Window;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView web;
    private String remoteUrl = "";
    private String fallbackUrl = "file:///android_asset/index.html";
    private boolean triedFallback = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(5, 7, 12));
        getWindow().setNavigationBarColor(Color.BLACK);

        web = new WebView(this);
        setContentView(web);
        configureWebView();
        loadConfiguration();
    }

    private void configureWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setBackgroundColor(Color.rgb(5, 7, 12));
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && !triedFallback) {
                    triedFallback = true;
                    view.loadUrl(fallbackUrl);
                }
            }
        });
    }

    private void loadConfiguration() {
        try (InputStream in = getAssets().open("config.json")) {
            byte[] data = new byte[in.available()];
            in.read(data);
            JSONObject o = new JSONObject(new String(data, StandardCharsets.UTF_8));
            remoteUrl = o.optString("website_url", "").trim();
            fallbackUrl = o.optString("fallback_asset", fallbackUrl);
        } catch (Exception ignored) {}

        if (remoteUrl.startsWith("https://") && !remoteUrl.contains("YOUR-LIVE-MCU-WEBSITE")) {
            web.loadUrl(remoteUrl);
        } else {
            web.loadUrl(fallbackUrl);
        }
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
