MCU BASELINE FAN HUB - ANDROID WEBVIEW APP

IMPORTANT:
1. This app is designed to load your LIVE website so website updates appear in the app without reinstalling.
2. Open app/src/main/assets/config.json and replace website_url with your real HTTPS website URL.
3. If the live website cannot be reached, the app automatically falls back to the bundled cinematic site.
4. The app targets Android 6.0+ (minSdk 23) and is intended for Samsung, Redmi/Xiaomi, Vivo, Oppo, Realme, OnePlus and other Android devices.
5. An APK file itself installs directly. A ZIP is only the source/build project and cannot be installed directly.

BUILD:
- Open this android folder in Android Studio and Build > Generate APK.
- Or push the folder to GitHub and run the included Actions workflow. The built APK is uploaded as an artifact.

NO REINSTALL FOR WEBSITE CONTENT:
Once website_url points to your live HTTPS site, edit/publish the website. The app loads that live site on next launch/refresh.
