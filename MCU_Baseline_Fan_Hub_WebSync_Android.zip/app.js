
const titles=[
["Iron Man",2008,"Movie","MCU"],["Iron Man 2",2010,"Movie","MCU"],["Iron Man 3",2013,"Movie","MCU"],["The Incredible Hulk",2008,"Movie","MCU"],
["Captain America: The First Avenger",2011,"Movie","MCU"],["Captain America: The Winter Soldier",2014,"Movie","MCU"],["Captain America: Civil War",2016,"Movie","MCU"],["Captain America: Brave New World",2025,"Movie","MCU"],
["Thor",2011,"Movie","MCU"],["Thor: The Dark World",2013,"Movie","MCU"],["Thor: Ragnarok",2017,"Movie","MCU"],["Thor: Love and Thunder",2022,"Movie","MCU"],
["Black Widow",2021,"Movie","MCU"],["Doctor Strange",2016,"Movie","MCU"],["Doctor Strange in the Multiverse of Madness",2022,"Movie","MCU"],["Black Panther",2018,"Movie","MCU"],["Black Panther: Wakanda Forever",2022,"Movie","MCU"],
["Ant-Man",2015,"Movie","MCU"],["Ant-Man and the Wasp",2018,"Movie","MCU"],["Ant-Man and the Wasp: Quantumania",2023,"Movie","MCU"],["Shang-Chi and the Legend of the Ten Rings",2021,"Movie","MCU"],["Thunderbolts*",2025,"Movie","MCU"],["Deadpool & Wolverine",2024,"Movie","MCU"],
["Loki Season 1",2021,"Series","MCU"],["Loki Season 2",2023,"Series","MCU"],["WandaVision",2021,"Series","MCU"],["The Falcon and the Winter Soldier",2021,"Series","MCU"],["Hawkeye",2021,"Series","MCU"],["Moon Knight",2022,"Series","MCU"],["She-Hulk: Attorney at Law",2022,"Series","MCU"],["Secret Invasion",2023,"Series","MCU"],["Daredevil: Born Again",2025,"Series","MCU"],
["Spider-Man",2002,"Movie","Spider-Verse"],["Spider-Man 2",2004,"Movie","Spider-Verse"],["Spider-Man 3",2007,"Movie","Spider-Verse"],["The Amazing Spider-Man",2012,"Movie","Spider-Verse"],["The Amazing Spider-Man 2",2014,"Movie","Spider-Verse"],["Spider-Man: Homecoming",2017,"Movie","Spider-Verse"],["Spider-Man: Far From Home",2019,"Movie","Spider-Verse"],["Spider-Man: No Way Home",2021,"Movie","Spider-Verse"],["Spider-Man: Into the Spider-Verse",2018,"Movie","Spider-Verse"],["Spider-Man: Across the Spider-Verse",2023,"Movie","Spider-Verse"],
["X-Men",2000,"Movie","X-Men"],["X2: X-Men United",2003,"Movie","X-Men"],["X-Men: The Last Stand",2006,"Movie","X-Men"],["X-Men Origins: Wolverine",2009,"Movie","X-Men"],["X-Men: First Class",2011,"Movie","X-Men"],["The Wolverine",2013,"Movie","X-Men"],["X-Men: Days of Future Past",2014,"Movie","X-Men"],["X-Men: Apocalypse",2016,"Movie","X-Men"],["Logan",2017,"Movie","X-Men"],["Dark Phoenix",2019,"Movie","X-Men"],["Deadpool",2016,"Movie","X-Men"],["Deadpool 2",2018,"Movie","X-Men"],
["Daredevil",2003,"Movie","Legacy"],["Ghost Rider",2007,"Movie","Legacy"],["Ghost Rider: Spirit of Vengeance",2011,"Movie","Legacy"],["Hulk",2003,"Movie","Legacy"]
].map((x,i)=>({id:i+1,name:x[0],year:x[1],type:x[2],universe:x[3]}));

let watched=new Set(JSON.parse(localStorage.getItem("mcu_watched")||"[]"));
let fav=new Set(JSON.parse(localStorage.getItem("mcu_fav")||"[]"));
const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const years=[...new Set(titles.map(x=>x.year))].sort((a,b)=>b-a);years.forEach(y=>$("#year").insertAdjacentHTML("beforeend",`<option>${y}</option>`));

function save(){localStorage.setItem("mcu_watched",JSON.stringify([...watched]));localStorage.setItem("mcu_fav",JSON.stringify([...fav]));}
function toast(t){let e=$("#toast");e.textContent=t;e.classList.add("show");clearTimeout(window.tt);window.tt=setTimeout(()=>e.classList.remove("show"),1700)}
function go(page){$$(".page").forEach(p=>p.classList.remove("active"));$("#"+page).classList.add("active");$$(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));window.scrollTo({top:0,behavior:"smooth"});render()}
$$(".nav button").forEach(b=>b.onclick=()=>go(b.dataset.page));
function toggleW(id){watched.has(id)?(watched.delete(id),toast("Removed from watched")):(watched.add(id),toast("Marked as watched ✓"));save();render()}
function toggleF(id){fav.has(id)?(fav.delete(id),toast("Removed from favorites")):(fav.add(id),toast("Saved to favorites ★"));save();render()}
function card(x,i=0){let w=watched.has(x.id),f=fav.has(x.id);return `<article class="card" style="animation-delay:${Math.min(i*35,350)}ms" onclick="openTitle(${x.id})" onpointermove="shine(event,this)"><div><div class="cardTop"><div><span class="badge red">${x.universe}</span> <span class="badge">${x.type}</span></div><span class="badge gold">${x.year}</span></div><h3>${x.name}</h3><div class="sub">TAP TO ENTER • FAN EXPERIENCE</div></div><div class="cardBottom"><button class="smallBtn ${w?'done':''}" onclick="event.stopPropagation();toggleW(${x.id})">${w?'✓ Watched':'Mark watched'}</button><button class="smallBtn star ${f?'on':''}" onclick="event.stopPropagation();toggleF(${x.id})">${f?'★':'☆'}</button></div></article>`}
function shine(e,el){const r=el.getBoundingClientRect();el.style.setProperty('--mx',((e.clientX-r.left)/r.width*100)+'%');el.style.setProperty('--my',((e.clientY-r.top)/r.height*100)+'%')}
const modeData={
 'Spider-Verse':{cls:'mode-spider',sigil:'🕷',desc:'Spider-style mode: web energy, multiverse pulse and a fast cinematic card experience.'},
 'MCU':{cls:'mode-iron',sigil:'⚡',desc:'Core MCU mode: enter the title, track your watch state and jump through the connected universe.'},
 'X-Men':{cls:'mode-mutant',sigil:'✕',desc:'Mutant mode: a legacy timeline view with a distinct gold-powered visual treatment.'},
 'Legacy':{cls:'mode-wakanda',sigil:'◆',desc:'Legacy mode: explore the wider Marvel screen universe beyond the main baseline.'}
};
function applyMode(universe){document.body.className=document.body.className.replace(/mode-\w+/g,'').trim();let d=modeData[universe]||modeData.MCU;document.body.classList.add(d.cls)}
function openTitle(id){let x=titles.find(t=>t.id===id);if(!x)return;let d=modeData[x.universe]||modeData.MCU;applyMode(x.universe);$('#modalSigil').textContent=d.sigil;$('#modalKicker').textContent=x.universe.toUpperCase()+' • IMMERSIVE MODE';$('#modalTitle').textContent=x.name;$('#modalDesc').textContent=d.desc;$('#dYear').textContent=x.year;$('#dType').textContent=x.type;$('#dUniverse').textContent=x.universe;$('#dWatch').textContent=watched.has(id)?'✓ Watched':'Mark watched';$('#dFav').textContent=fav.has(id)?'★':'☆';$('#dWatch').onclick=()=>{toggleW(id);openTitle(id)};$('#dFav').onclick=()=>{toggleF(id);openTitle(id)};$('#modeStrip').innerHTML=Object.keys(modeData).map(u=>`<button class="modeBtn ${u===x.universe?'on':''}" onclick="applyMode('${u}')">${u} mode</button>`).join('');$('#detailModal').classList.add('show');document.body.style.overflow='hidden'}
function closeDetail(){$('#detailModal').classList.remove('show');document.body.style.overflow='';document.body.className=''}
function openHero(name){const map={'Spider-Man':'Spider-Verse','Iron Man':'MCU','Thor':'MCU','Black Panther':'Legacy','Doctor Strange':'MCU','Wolverine':'X-Men','Deadpool':'X-Men','Loki':'MCU','Hulk':'MCU','Captain America':'MCU','Black Widow':'MCU','Daredevil':'Legacy'};let u=map[name]||'MCU';applyMode(u);let sig={'Spider-Man':'🕷','Iron Man':'⚙','Thor':'⚡','Black Panther':'◆','Doctor Strange':'✦','Wolverine':'✕','Deadpool':'☠','Loki':'♢','Hulk':'●','Captain America':'★','Black Widow':'◉','Daredevil':'◒'}[name]||'✦';$('#modalSigil').textContent=sig;$('#modalKicker').textContent=name.toUpperCase()+' • HERO MODE';$('#modalTitle').textContent=name;$('#modalDesc').textContent='Hero mode activated. Switch visual modes below or jump into a matching title from the Library.';$('#dYear').textContent='HERO';$('#dType').textContent='PROFILE';$('#dUniverse').textContent=u;$('#dWatch').style.display='none';$('#dFav').style.display='none';$('#modeStrip').innerHTML=Object.keys(modeData).map(v=>`<button class="modeBtn ${v===u?'on':''}" onclick="applyMode('${v}')">${v} mode</button>`).join('');$('#detailModal').classList.add('show');document.body.style.overflow='hidden'}
function render(){
let total=titles.length,w=watched.size,f=fav.size,p=Math.round(w/total*100)||0;
$("#mW").textContent=w;$("#mF").textContent=f;$("#mT").textContent=total;$("#mP").textContent=p+"%";$("#pText").textContent=`${w} / ${total} watched`;$("#pPct").textContent=p+"%";$("#pBar").style.width=p+"%";
let q=($("#search")?.value||"").trim().toLowerCase(),u=$("#universe")?.value||"All Universes",k=$("#kind")?.value||"All Types",y=$("#year")?.value||"All Years";
let arr=titles.filter(x=>(!q||x.name.toLowerCase().includes(q)||x.universe.toLowerCase().includes(q)||String(x.year).includes(q))&&(u==="All Universes"||x.universe===u)&&(k==="All Types"||x.type===k)&&(y==="All Years"||String(x.year)===y));
$("#result").textContent=arr.length+" titles";$("#libraryGrid").innerHTML=arr.map(card).join("")||'<div class="empty">Nothing matched. Try another search or filter.</div>';
let queue=titles.filter(x=>!watched.has(x.id)).slice(0,8);$("#homeGrid").innerHTML=queue.map(card).join("")||'<div class="empty">Universe complete. Everything is marked watched! 🔥</div>';
$("#favGrid").innerHTML=titles.filter(x=>fav.has(x.id)).map(card).join("")||'<div class="empty">No favorites yet. Save cards with ☆ and they will appear here.</div>';
const chars=[["Iron Man","Tony Stark","⚙"],["Captain America","Steve Rogers","★"],["Thor","God of Thunder","⚡"],["Spider-Man","Peter Parker","🕷"],["Black Panther","Wakanda","◆"],["Doctor Strange","Stephen Strange","✦"],["Wolverine","Logan","✕"],["Deadpool","Wade Wilson","☠"],["Loki","God of Mischief","♢"],["Hulk","Bruce Banner","●"],["Black Widow","Natasha Romanoff","◉"],["Daredevil","Matt Murdock","◒"]];
$("#chars").innerHTML=chars.map(c=>`<div class="char" onclick="openHero('${c[0]}')"><div class="avatar">${c[2]}</div><b>${c[0]}</b><span>${c[1]}</span></div>`).join("");
}
["search","universe","kind","year"].forEach(id=>$(("#"+id)).addEventListener("input",render));
function resetAll(){if(confirm("Clear all watched and favorite data?")){watched.clear();fav.clear();save();render();toast("Local data cleared")}}
let deferred=null;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferred=e});async function installApp(){if(deferred){deferred.prompt();await deferred.userChoice;deferred=null}else toast("Use your browser menu → Add to Home screen")}
if("serviceWorker" in navigator)navigator.serviceWorker.register("sw.js");
render();
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeDetail()});
