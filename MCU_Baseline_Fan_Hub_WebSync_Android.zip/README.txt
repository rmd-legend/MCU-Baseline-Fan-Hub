MCU Baseline Fan Hub PRO — Cinematic Edition

This version is a mobile-first PWA/WebView-ready fan app.

New experience:
- Tap any movie card to open a full-screen cinematic profile.
- Character-specific visual accent, icon, description, hero, suit/look, cast and universe notes.
- Animated poster, glow, particles and responsive mobile layout.
- Watched/favorite state is saved locally.
- Works as a web app and can be wrapped in Android WebView.

For a production APK, open the Android WebView project in Android Studio and build an APK.
All Marvel names, characters and marks remain property of their respective rights holders.
