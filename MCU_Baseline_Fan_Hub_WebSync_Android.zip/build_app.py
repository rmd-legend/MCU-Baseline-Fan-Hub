from pathlib import Path
p=Path('/mnt/data/mcu_project/base.html')
s=p.read_text()
# Add cinematic CSS before </style>
css=r'''
/* CINEMATIC DETAIL EXPERIENCE */
.detailOverlay{position:fixed;inset:0;z-index:200;background:#030409f2;backdrop-filter:blur(18px);display:none;overflow:auto}
.detailOverlay.open{display:block;animation:fadeIn .28s ease}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
.detailShell{min-height:100%;position:relative;overflow:hidden;background:radial-gradient(circle at 80% 15%,var(--accent2,#e51c32)2e,transparent 30%),linear-gradient(135deg,#07080d 0%,#0d111a 48%,#05060a 100%)}
.detailBackdrop{position:absolute;inset:0;opacity:.5;background:radial-gradient(circle at 25% 20%,var(--accent,#e51c32)22%,transparent 34%),radial-gradient(circle at 80% 75%,#ffffff08,transparent 32%);filter:saturate(1.25)}
.detailGrid{position:absolute;inset:0;background-image:linear-gradient(#fff06 1px,transparent 1px),linear-gradient(90deg,#fff06 1px,transparent 1px);background-size:70px 70px;mask-image:linear-gradient(to bottom,#000,transparent 80%);opacity:.22}
.detailClose{position:absolute;right:18px;top:18px;z-index:4;width:46px;height:46px;border-radius:50%;border:1px solid #ffffff2a;background:#090b10cc;color:#fff;font-size:24px;cursor:pointer}
.detailContent{position:relative;z-index:2;max-width:1180px;margin:auto;padding:76px 22px 55px;display:grid;grid-template-columns:minmax(270px,390px) 1fr;gap:34px;align-items:center;min-height:100vh}
.poster{min-height:500px;border-radius:30px;border:1px solid #ffffff25;box-shadow:0 30px 100px #000b;position:relative;overflow:hidden;display:flex;align-items:flex-end;padding:26px;background:linear-gradient(145deg,var(--accent,#e51c32),#080a10 65%)}
.poster:before{content:"";position:absolute;inset:12%;border:1px solid #fff2;border-radius:50%;box-shadow:0 0 100px var(--accent,#e51c32);transform:rotate(-18deg);opacity:.7}
.poster:after{content:"";position:absolute;inset:0;background:linear-gradient(to top,#000d,transparent 58%),radial-gradient(circle at 50% 30%,#fff2,transparent 25%)}
.posterArt{position:absolute;inset:0;display:grid;place-items:center;font-size:130px;filter:drop-shadow(0 20px 20px #000);z-index:1;animation:heroFloat 4s ease-in-out infinite}
@keyframes heroFloat{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-10px) scale(1.04)}}
.posterLabel{position:relative;z-index:2}.posterLabel small{letter-spacing:4px;color:#fff9;font-weight:900}.posterLabel h2{font-size:clamp(30px,5vw,52px);line-height:.95;margin:8px 0 0;letter-spacing:-2px}
.detailInfo .eyebrow{color:var(--accent,#ff5262);font-weight:900;letter-spacing:3px;font-size:11px}.detailInfo h1{font-size:clamp(42px,7vw,78px);line-height:.9;letter-spacing:-4px;margin:10px 0 14px}.detailInfo .desc{color:#c6ccd7;line-height:1.7;max-width:760px;font-size:15px}.detailMeta{display:flex;flex-wrap:wrap;gap:8px;margin:18px 0}.detailPill{padding:8px 11px;border:1px solid #ffffff18;border-radius:99px;background:#ffffff08;color:#dbe0e8;font-size:11px}.detailActions{display:flex;gap:9px;flex-wrap:wrap;margin:22px 0}.detailBtn{border:1px solid #ffffff20;background:#11151e;color:#fff;border-radius:13px;padding:12px 16px;cursor:pointer}.detailBtn.primary{background:var(--accent,#e51c32);border-color:var(--accent,#e51c32);font-weight:900}.detailSections{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:22px}.detailBox{border:1px solid #ffffff12;background:#0b0e15b8;border-radius:18px;padding:16px}.detailBox b{font-size:12px;color:#fff}.detailBox p{font-size:12px;line-height:1.55;color:#8993a3;margin:8px 0 0}.spark{position:absolute;width:4px;height:4px;border-radius:50%;background:#fff;box-shadow:0 0 14px #fff;opacity:.7;animation:spark 4s linear infinite}.s1{left:12%;top:24%}.s2{left:70%;top:18%;animation-delay:1s}.s3{left:84%;top:62%;animation-delay:2s}.s4{left:31%;top:76%;animation-delay:3s}@keyframes spark{0%{transform:translateY(20px);opacity:0}20%,70%{opacity:.8}100%{transform:translateY(-100px);opacity:0}}
@media(max-width:800px){.detailContent{grid-template-columns:1fr;padding-top:78px;gap:18px}.poster{min-height:390px}.detailSections{grid-template-columns:1fr}.detailInfo h1{letter-spacing:-2px}}
'''
s=s.replace('</style>',css+'</style>')
# Insert modal before toast
modal=r'''
<div class="detailOverlay" id="detailOverlay" aria-hidden="true">
  <div class="detailShell" id="detailShell">
    <div class="detailBackdrop"></div><div class="detailGrid"></div>
    <span class="spark s1"></span><span class="spark s2"></span><span class="spark s3"></span><span class="spark s4"></span>
    <button class="detailClose" onclick="closeDetail()" aria-label="Close">×</button>
    <div class="detailContent">
      <div class="poster" id="detailPoster"><div class="posterArt" id="posterArt">✦</div><div class="posterLabel"><small id="posterUniverse">MARVEL UNIVERSE</small><h2 id="posterTitle">TITLE</h2></div></div>
      <div class="detailInfo">
        <div class="eyebrow" id="detailEyebrow">CINEMATIC PROFILE</div>
        <h1 id="detailTitle">Title</h1>
        <p class="desc" id="detailDesc"></p>
        <div class="detailMeta" id="detailMeta"></div>
        <div class="detailActions"><button class="detailBtn primary" id="detailWatch">Mark Watched</button><button class="detailBtn" id="detailFav">☆ Save</button></div>
        <div class="detailSections">
          <div class="detailBox"><b>Hero / Lead</b><p id="detailHero"></p></div>
          <div class="detailBox"><b>Suit / Look</b><p id="detailSuit"></p></div>
          <div class="detailBox"><b>Key Characters</b><p id="detailCast"></p></div>
          <div class="detailBox"><b>Universe Notes</b><p id="detailNotes"></p></div>
        </div>
      </div>
    </div>
  </div>
</div>
'''
s=s.replace('<div class="toast" id="toast"></div>',modal+'<div class="toast" id="toast"></div>')
# Replace card function and add details map/functions before render
old='function card(x,i=0){let w=watched.has(x.id),f=fav.has(x.id);return `<article class="card" style="animation-delay:${Math.min(i*35,350)}ms"><div><div class="cardTop"><div><span class="badge red">${x.universe}</span> <span class="badge">${x.type}</span></div><span class="badge gold">${x.year}</span></div><h3>${x.name}</h3><div class="sub">MCU BASELINE • FAN CARD</div></div><div class="cardBottom"><button class="smallBtn ${w?\'done\':\'\'}" onclick="toggleW(${x.id})">${w?\'✓ Watched\':\'Mark watched\'}</button><button class="smallBtn star ${f?\'on\':\'\'}" onclick="toggleF(${x.id})">${f?\'★\':\'☆\'}</button></div></article>`}'
new=r'''const profiles={
"Iron Man":{hero:"Tony Stark / Iron Man",suit:"Mark III-inspired armored suit — red/gold tech aesthetic.",cast:"Tony Stark, Pepper Potts, James Rhodes, Obadiah Stane",notes:"The origin point of the MCU's connected superhero era.",desc:"Tony Stark is forced to rethink what his technology means after a life-changing experience. The film establishes the high-tech armor, Stark Industries world and the personality that anchors the early MCU.",icon:"⚙",accent:"#d92835"},
"Iron Man 2":{hero:"Tony Stark / Iron Man",suit:"Mark IV, Mark V and Mark VI armor concepts.",cast:"Tony Stark, Pepper Potts, Natasha Romanoff, James Rhodes",notes:"Armor evolution, Stark Expo and the road toward the Avengers.",desc:"A faster, bigger chapter in Tony Stark's story, mixing new armor technology, rival forces and the expanding superhero world around him.",icon:"⚡",accent:"#c94a38"},
"Spider-Man":{hero:"Peter Parker / Spider-Man",suit:"Classic red-and-blue web suit with web-shooter identity.",cast:"Peter Parker, Mary Jane Watson, Harry Osborn, Norman Osborn",notes:"A standalone Spider-Man era with a classic origin-story tone.",desc:"Peter Parker balances school, responsibility and his new abilities while learning what it means to become Spider-Man.",icon:"🕷",accent:"#d61f2c"},
"Spider-Man: No Way Home":{hero:"Peter Parker / Spider-Man",suit:"Integrated suit and upgraded web-tech designs.",cast:"Peter Parker, Doctor Strange, MJ, Ned, multiverse visitors",notes:"A multiverse collision brings different Spider-Man worlds together.",desc:"Peter Parker's identity becomes impossible to keep private, opening a dangerous path into the multiverse and forcing him to confront the consequences.",icon:"🕷",accent:"#b51f35"},
"Captain America: The First Avenger":{hero:"Steve Rogers / Captain America",suit:"Classic star-spangled vibranium shield era uniform.",cast:"Steve Rogers, Peggy Carter, Bucky Barnes, Red Skull",notes:"The WWII origin of Captain America and the super-soldier legacy.",desc:"Steve Rogers becomes Captain America and is pulled into a wartime fight that creates the foundation for his future legacy.",icon:"★",accent:"#315d9c"},
"Thor":{hero:"Thor Odinson",suit:"Asgardian armor, red cape and Mjolnir.",cast:"Thor, Loki, Jane Foster, Odin",notes:"Introduces Asgard, the Nine Realms and Thor's heroic journey.",desc:"A powerful Asgardian prince is sent to Earth and must learn humility before he can reclaim his place as a hero.",icon:"⚡",accent:"#5a7ec8"},
"Black Panther":{hero:"T'Challa / Black Panther",suit:"Vibranium kinetic suit with Wakandan technology.",cast:"T'Challa, Shuri, Okoye, Nakia, Erik Killmonger",notes:"Wakanda becomes one of the MCU's richest cultures and technology hubs.",desc:"T'Challa returns home to take his place as king, but a challenger forces him to confront the responsibilities of leadership.",icon:"◆",accent:"#7143c5"},
"Doctor Strange":{hero:"Stephen Strange / Doctor Strange",suit:"Mystic robes, Eye of Agamotto and magical artifacts.",cast:"Stephen Strange, Wong, Ancient One, Kaecilius",notes:"Introduces the mystical side of the MCU and alternate dimensions.",desc:"A brilliant surgeon discovers the mystic arts and learns that reality is far stranger than he imagined.",icon:"✦",accent:"#d77a2f"},
"Wolverine":{hero:"Logan / Wolverine",suit:"Adamantium-clawed mutant with regenerative healing.",cast:"Logan, Professor X, X-Men allies and enemies",notes:"A mutant legacy centered on Logan's identity and survival.",desc:"Logan is a hardened mutant whose healing ability and adamantium skeleton make him one of the most recognizable characters in the X-Men universe.",icon:"✕",accent:"#c7a21b"},
"Deadpool":{hero:"Wade Wilson / Deadpool",suit:"Red-and-black tactical suit with dual katanas.",cast:"Wade Wilson, Vanessa, Colossus, Negasonic Teenage Warhead",notes:"An irreverent mutant antihero with a self-aware style.",desc:"Wade Wilson becomes Deadpool and turns superhero storytelling into a chaotic, fourth-wall-breaking adventure.",icon:"☠",accent:"#d31e31"}
};
function profileFor(x){return profiles[x.name]||{hero:x.name,suit:"Signature character design and universe costume.",cast:"Featured characters from this title",notes:`${x.universe} • ${x.type} • ${x.year}`,desc:`Explore ${x.name} through the MCU Baseline fan experience — story, characters, visual identity and universe notes in one cinematic profile.`,icon:"✦",accent:"#e51c32"}}
function card(x,i=0){let w=watched.has(x.id),f=fav.has(x.id);return `<article class="card" onclick="openDetail(${x.id})" style="animation-delay:${Math.min(i*35,350)}ms"><div><div class="cardTop"><div><span class="badge red">${x.universe}</span> <span class="badge">${x.type}</span></div><span class="badge gold">${x.year}</span></div><h3>${x.name}</h3><div class="sub">TOUCH TO ENTER CINEMATIC VIEW</div></div><div class="cardBottom"><button class="smallBtn ${w?'done':''}" onclick="event.stopPropagation();toggleW(${x.id})">${w?'✓ Watched':'Mark watched'}</button><button class="smallBtn star ${f?'on':''}" onclick="event.stopPropagation();toggleF(${x.id})">${f?'★':'☆'}</button></div></article>`}
function openDetail(id){const x=titles.find(t=>t.id===id);if(!x)return;const d=profileFor(x);const root=$("#detailShell");root.style.setProperty("--accent",d.accent);root.style.setProperty("--accent2",d.accent);$("#detailOverlay").classList.add("open");$("#detailOverlay").setAttribute("aria-hidden","false");document.body.style.overflow="hidden";$("#detailEyebrow").textContent=`${x.universe.toUpperCase()} • ${x.type.toUpperCase()} • ${x.year}`;$("#detailTitle").textContent=x.name;$("#posterTitle").textContent=x.name;$("#posterUniverse").textContent=x.universe.toUpperCase();$("#posterArt").textContent=d.icon;$("#detailDesc").textContent=d.desc;$("#detailHero").textContent=d.hero;$("#detailSuit").textContent=d.suit;$("#detailCast").textContent=d.cast;$("#detailNotes").textContent=d.notes;$("#detailWatch").textContent=watched.has(id)?"✓ Watched":"Mark Watched";$("#detailFav").textContent=fav.has(id)?"★ Saved":"☆ Save";$("#detailWatch").onclick=()=>{toggleW(id);openDetail(id)};$("#detailFav").onclick=()=>{toggleF(id);openDetail(id)}}
function closeDetail(){$("#detailOverlay").classList.remove("open");$("#detailOverlay").setAttribute("aria-hidden","true");document.body.style.overflow=""}
$("#detailOverlay").addEventListener("click",e=>{if(e.target.id==="detailOverlay")closeDetail()});document.addEventListener("keydown",e=>{if(e.key==="Escape")closeDetail()});
'''
if old not in s:
    raise SystemExit('old card function not found')
s=s.replace(old,new)
# Add clickable character cards that open a profile-ish title if possible; easiest leave.
p.write_text(s)
print('built',p)
