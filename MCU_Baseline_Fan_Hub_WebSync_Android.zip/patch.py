from pathlib import Path
p=Path('/mnt/data/mcu_project/index.html')
s=p.read_text()
# inject advanced CSS before </style>
css=r'''
/* NEXT-GEN TOUCH EXPERIENCE */
:root{--accent:#e51c32;--accent2:#ff5262;--glow:#e51c3260}
button,.card,.char,.phase{touch-action:manipulation;-webkit-tap-highlight-color:transparent}
.card{cursor:pointer;isolation:isolate}.card:after{content:"";position:absolute;inset:0;background:radial-gradient(circle at var(--mx,50%) var(--my,50%),#fff2,transparent 30%);opacity:0;transition:.25s;pointer-events:none}.card:active{transform:scale(.985)}.card:hover:after{opacity:1}
.char{cursor:pointer;position:relative;overflow:hidden}.char:after{content:"TAP TO ENTER";position:absolute;right:12px;bottom:12px;font-size:8px;letter-spacing:1.5px;color:#667084;opacity:.8}
.modal{position:fixed;inset:0;display:none;place-items:end center;background:#0009;backdrop-filter:blur(12px);z-index:200;padding:12px}.modal.show{display:grid;animation:fadeIn .2s ease}.modalPanel{width:min(720px,100%);max-height:90vh;overflow:auto;border:1px solid #ffffff18;border-radius:28px 28px 18px 18px;background:linear-gradient(145deg,#171b26,#0b0e14);box-shadow:0 30px 100px #000;animation:sheet .28s cubic-bezier(.2,.8,.2,1)}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}@keyframes sheet{from{transform:translateY(40px);opacity:.5}to{transform:none;opacity:1}}
.modalHero{min-height:230px;padding:26px;position:relative;overflow:hidden;background:radial-gradient(circle at 85% 20%,var(--glow),transparent 35%),linear-gradient(135deg,#210811,#10141d)}.modalHero .sigil{font-size:72px;line-height:1;filter:drop-shadow(0 0 22px var(--glow))}.modalHero h2{font-size:32px;margin:12px 0 5px;letter-spacing:-1.5px}.modalHero p{margin:0;color:#9ba4b3;font-size:12px;max-width:540px;line-height:1.6}.modalClose{position:absolute;right:16px;top:16px;width:40px;height:40px;border-radius:50%;border:1px solid #ffffff18;background:#0006;color:#fff;font-size:18px}.modalBody{padding:20px}.detailGrid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.detailBox{padding:13px;border:1px solid var(--line);border-radius:15px;background:#0d1017}.detailBox b{display:block;font-size:15px}.detailBox span{font-size:10px;color:#7f8999}.modeStrip{display:flex;gap:8px;overflow:auto;margin:14px 0}.modeBtn{white-space:nowrap;border:1px solid var(--line);background:#0c0f15;color:#cdd3dc;border-radius:99px;padding:9px 12px;font-size:11px}.modeBtn.on{background:var(--accent);border-color:var(--accent);color:#fff}.energy{height:6px;background:#262c37;border-radius:99px;overflow:hidden;margin-top:14px}.energy i{display:block;height:100%;width:72%;background:linear-gradient(90deg,var(--accent),var(--accent2),var(--gold));animation:energy 1.4s ease-in-out infinite alternate}@keyframes energy{to{width:96%}}
body.mode-spider{--accent:#e41e3a;--accent2:#ef3340;--glow:#ef334080;background:radial-gradient(circle at 80% 10%,#e41e3a22,transparent 30%),radial-gradient(circle at 20% 90%,#2563eb1d,transparent 30%),#05070d}body.mode-spider:before{background-image:linear-gradient(60deg,#fff 1px,transparent 1px),linear-gradient(-60deg,#fff 1px,transparent 1px);background-size:80px 80px;opacity:.12}
body.mode-iron{--accent:#ff4b36;--accent2:#ffd15a;--glow:#ff5b3d70}body.mode-thor{--accent:#62d9ff;--accent2:#d7ecff;--glow:#62d9ff70}body.mode-wakanda{--accent:#a96bff;--accent2:#62e6d5;--glow:#a96bff70}body.mode-mutant{--accent:#f2c968;--accent2:#f7f7f7;--glow:#f2c96870}
@media(max-width:480px){.modal{padding:0}.modalPanel{border-radius:26px 26px 0 0;max-height:94vh}.modalHero{min-height:245px}.detailGrid{grid-template-columns:1fr 1fr}.heroBtns .chip{flex:1}.card:hover{transform:none}}
'''
s=s.replace('</style>',css+'</style>')
# add modal markup before toast
modal=r'''
<div class="modal" id="detailModal" onclick="if(event.target===this)closeDetail()">
 <div class="modalPanel">
  <div class="modalHero" id="modalHero"><button class="modalClose" onclick="closeDetail()">×</button><div class="sigil" id="modalSigil">✦</div><div class="kicker" id="modalKicker">UNIVERSE MODE</div><h2 id="modalTitle">Title</h2><p id="modalDesc">Explore this universe.</p><div class="energy"><i></i></div></div>
  <div class="modalBody"><div class="detailGrid"><div class="detailBox"><b id="dYear">—</b><span>RELEASE YEAR</span></div><div class="detailBox"><b id="dType">—</b><span>FORMAT</span></div><div class="detailBox"><b id="dUniverse">—</b><span>UNIVERSE</span></div></div><div class="modeStrip" id="modeStrip"></div><div class="cardBottom"><button class="smallBtn" id="dWatch">Mark watched</button><button class="smallBtn star" id="dFav">☆</button></div></div>
 </div>
</div>
'''
s=s.replace('<div class="toast" id="toast"></div>',modal+'<div class="toast" id="toast"></div>')
# replace card function
start=s.index('function card('); end=s.index('function render()',start)
new=r'''function card(x,i=0){let w=watched.has(x.id),f=fav.has(x.id);return `<article class="card" style="animation-delay:${Math.min(i*35,350)}ms" onclick="openTitle(${x.id})" onpointermove="shine(event,this)"><div><div class="cardTop"><div><span class="badge red">${x.universe}</span> <span class="badge">${x.type}</span></div><span class="badge gold">${x.year}</span></div><h3>${x.name}</h3><div class="sub">TAP TO ENTER • FAN EXPERIENCE</div></div><div class="cardBottom"><button class="smallBtn ${w?'done':''}" onclick="event.stopPropagation();toggleW(${x.id})">${w?'✓ Watched':'Mark watched'}</button><button class="smallBtn star ${f?'on':''}" onclick="event.stopPropagation();toggleF(${x.id})">${f?'★':'☆'}</button></div></article>`}
function shine(e,el){const r=el.getBoundingClientRect();el.style.setProperty('--mx',((e.clientX-r.left)/r.width*100)+'%');el.style.setProperty('--my',((e.clientY-r.top)/r.height*100)+'%')}
const modeData={
 'Spider-Verse':{cls:'mode-spider',sigil:'🕷',desc:'Spider-style mode: web energy, multiverse pulse and a fast cinematic card experience.'},
 'MCU':{cls:'mode-iron',sigil:'⚡',desc:'Core MCU mode: enter the title, track your watch state and jump through the connected universe.'},
 'X-Men':{cls:'mode-mutant',sigil:'✕',desc:'Mutant mode: a legacy timeline view with a distinct gold-powered visual treatment.'},
 'Legacy':{cls:'mode-wakanda',sigil:'◆',desc:'Legacy mode: explore the wider Marvel screen universe beyond the main baseline.'}
};
function applyMode(universe){document.body.className=document.body.className.replace(/mode-\w+/g,'').trim();let d=modeData[universe]||modeData.MCU;document.body.classList.add(d.cls)}
function openTitle(id){let x=titles.find(t=>t.id===id);if(!x)return;let d=modeData[x.universe]||modeData.MCU;applyMode(x.universe);$('#modalSigil').textContent=d.sigil;$('#modalKicker').textContent=x.universe.toUpperCase()+' • IMMERSIVE MODE';$('#modalTitle').textContent=x.name;$('#modalDesc').textContent=d.desc;$('#dYear').textContent=x.year;$('#dType').textContent=x.type;$('#dUniverse').textContent=x.universe;$('#dWatch').textContent=watched.has(id)?'✓ Watched':'Mark watched';$('#dFav').textContent=fav.has(id)?'★':'☆';$('#dWatch').onclick=()=>{toggleW(id);openTitle(id)};$('#dFav').onclick=()=>{toggleF(id);openTitle(id)};$('#modeStrip').innerHTML=Object.keys(modeData).map(u=>`<button class="modeBtn ${u===x.universe?'on':''}" onclick="applyMode('${u}')">${u} mode</button>`).join('');$('#detailModal').classList.add('show');document.body.style.overflow='hidden'}
function closeDetail(){$('#detailModal').classList.remove('show');document.body.style.overflow='';document.body.className=''}
function openHero(name){const map={'Spider-Man':'Spider-Verse','Iron Man':'MCU','Thor':'MCU','Black Panther':'Legacy','Doctor Strange':'MCU','Wolverine':'X-Men','Deadpool':'X-Men','Loki':'MCU','Hulk':'MCU','Captain America':'MCU','Black Widow':'MCU','Daredevil':'Legacy'};let u=map[name]||'MCU';applyMode(u);let sig={'Spider-Man':'🕷','Iron Man':'⚙','Thor':'⚡','Black Panther':'◆','Doctor Strange':'✦','Wolverine':'✕','Deadpool':'☠','Loki':'♢','Hulk':'●','Captain America':'★','Black Widow':'◉','Daredevil':'◒'}[name]||'✦';$('#modalSigil').textContent=sig;$('#modalKicker').textContent=name.toUpperCase()+' • HERO MODE';$('#modalTitle').textContent=name;$('#modalDesc').textContent='Hero mode activated. Switch visual modes below or jump into a matching title from the Library.';$('#dYear').textContent='HERO';$('#dType').textContent='PROFILE';$('#dUniverse').textContent=u;$('#dWatch').style.display='none';$('#dFav').style.display='none';$('#modeStrip').innerHTML=Object.keys(modeData).map(v=>`<button class="modeBtn ${v===u?'on':''}" onclick="applyMode('${v}')">${v} mode</button>`).join('');$('#detailModal').classList.add('show');document.body.style.overflow='hidden'}
'''
s=s[:start]+new+s[end:]
# make character cards clickable
s=s.replace('`<div class="char"><div class="avatar">${c[2]}</div><b>${c[0]}</b><span>${c[1]}</span></div>`','`<div class="char" onclick="openHero(\'${c[0]}\')"><div class="avatar">${c[2]}</div><b>${c[0]}</b><span>${c[1]}</span></div>`')
# Add keyboard escape
s=s.replace('render();\n</script>','render();\ndocument.addEventListener("keydown",e=>{if(e.key==="Escape")closeDetail()});\n</script>')
p.write_text(s)
